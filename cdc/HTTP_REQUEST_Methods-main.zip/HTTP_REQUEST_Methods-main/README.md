# HTTP REQUEST Methods

<p>
 Here we discuss the most commonly used HTTP methods POST, GET, PUT, PATCH, DELETE using javascript fetch api.
</p>
<p>
Here we using this fake API for a demonstration. with credits to https://jsonplaceholder.typicode.com/
</p>
<a href='https://medium.com/me/stats/post/e37a8416e2a0'>Read the full article 🤜</a>
